% Create the DUT, a lossy channel
SymbolTime = 180e-12;
OSR = 16;
Ts = SymbolTime/OSR;
channelLoss = 1.2; %dB
chan = serdes.ChannelLoss(Loss=channelLoss,dt=Ts);
impulse0 = chan.impulse;

% Create stimulus waveform
NSymbols = 300;
N = NSymbols*OSR; 
waveIn = zeros(N,1);
stim = serdes.Stimulus(...
    Specification='Random Symbols',...
    Modulation=3,...
    Delay=50e-12);
for ii = 1:N
    waveIn(ii) = step(stim);
end