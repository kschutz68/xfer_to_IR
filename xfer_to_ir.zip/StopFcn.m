fr = out.logsout{1}.Values.Data; % fr = freq response
fr = fr(:,:,end);
frfull = [fr;conj(fr(end-1:-1:2))]; % double-sided
ir_computed = real(ifft(frfull));
tvec1 = [0:Ts:length(ir_computed)*Ts];
tvec2 = [0:Ts:length(impulse0)*Ts];
figure;plot(1e9*tvec1(1:end-1),ir_computed/Ts,'b',1e9*tvec2(1:end-1),impulse0,'r');grid on
legend('Derived IR','Original IR')
xlabel('nseconds')
title('Impulse Response Comparisons');

pr_computed = impulse2pulse(ir_computed,OSR,Ts);
pr_orig = impulse2pulse(impulse0,OSR,Ts);
figure;plot(1e9*tvec1(1:end-1),pr_computed/Ts,'b',1e9*tvec2(1:end-1),pr_orig,'r');grid on
legend('Derived PR','Original PR')
xlabel('nseconds')
title('Pulse Response Comparisons');


